let workers = [];
let activities = [];
let reports = [];
let timers = {};
let timerIntervals = {};

function login() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const errorDiv = document.getElementById('login-error');

  if (username === 'admin' && password === 'admin') {
    document.getElementById('login-container').style.display = 'none';
    document.getElementById('main-container').style.display = 'block';
    errorDiv.textContent = '';
    updateWorkerButtons();
  } else {
    errorDiv.textContent = 'Credenciales incorrectas';
  }
}

function addWorker() {
  const name = document.getElementById('worker-name').value;
  const errorDiv = document.getElementById('worker-error');

  if (name) {
    workers.push({ name, activities: [] });
    updateWorkerSelect();
    updateWorkerButtons();
    document.getElementById('worker-name').value = '';
    errorDiv.textContent = '';
  } else {
    errorDiv.textContent = 'El nombre del trabajador no puede estar vacío';
  }
}

function addActivity() {
  const name = document.getElementById('activity-name').value;
  const perHour = document.getElementById('per-hour').value;
  const perMinute = document.getElementById('per-minute').value;
  const errorDiv = document.getElementById('activity-error');

  if (name && perHour && perMinute) {
    activities.push({ name, perHour, perMinute });
    updateActivitySelect();
    document.getElementById('activity-name').value = '';
    document.getElementById('per-hour').value = '';
    document.getElementById('per-minute').value = '';
    errorDiv.textContent = '';
  } else {
    errorDiv.textContent = 'Todos los campos son obligatorios';
  }
}

function updateWorkerSelect() {
  const workerSelect = document.getElementById('worker-select');
  workerSelect.innerHTML = '<option value="">Seleccione un Trabajador</option>';
  workers.forEach(worker => {
    const option = document.createElement('option');
    option.value = worker.name;
    option.textContent = worker.name;
    workerSelect.appendChild(option);
  });
}

function updateActivitySelect() {
  const activitySelect = document.getElementById('activity-select');
  activitySelect.innerHTML = '<option value="">Seleccione una Actividad</option>';
  activities.forEach(activity => {
    const option = document.createElement('option');
    option.value = activity.name;
    option.textContent = activity.name;
    activitySelect.appendChild(option);
  });
}

function updateWorkerButtons() {
  const workerButtonsContainer = document.getElementById('worker-buttons');
  workerButtonsContainer.innerHTML = '';
  
  workers.forEach(worker => {
    const button = document.createElement('button');
    button.textContent = `Finalizar Unidad - ${worker.name}`;
    button.classList.add('worker-button');
    button.onclick = () => finishUnit(worker.name);
    workerButtonsContainer.appendChild(button);
  });
}

function finishUnit(workerName) {
  const worker = workers.find(worker => worker.name === workerName);

  if (worker) {
    const activeTimers = Object.keys(timers).filter(timerId => timers[timerId].worker === workerName);

    activeTimers.forEach(timerId => {
      clearInterval(timerIntervals[timerId]);
      const endTime = new Date();
      const startTime = timers[timerId].startTime;
      const durationSeconds = Math.round((endTime - startTime) / 1000);
      const durationMinutes = Math.floor(durationSeconds / 60);
      const remainingSeconds = durationSeconds % 60;

      const activity = worker.activities.find(activity => activity.name === timers[timerId].activity);

      if (activity) {
        activity.durationInSeconds = (activity.durationInSeconds || 0) + durationSeconds;
      } else {
        worker.activities.push({
          name: timers[timerId].activity,
          startTime: startTime.toISOString()
        });
      }

      reports.push({
        worker: workerName,
        activity: timers[timerId].activity,
        startTime: startTime.toISOString(),
        durationMinutes,
        durationSeconds
      });

      delete timers[timerId];
      delete timerIntervals[timerId];
    });

    updateReportsTable();
  }
}

function startTimer() {
  const selectedWorker = document.getElementById('worker-select').value;
  const selectedActivity = document.getElementById('activity-select').value;

  if (selectedWorker && selectedActivity) {
    const timerId = `${selectedWorker}-${selectedActivity}`;
    if (!timers[timerId]) {
      timers[timerId] = { worker: selectedWorker, activity: selectedActivity, startTime: new Date() };
      timerIntervals[timerId] = setInterval(() => updateTimer(timerId), 1000);
    }
  } else {
    alert('Seleccione un trabajador y una actividad');
  }
}

function stopTimer() {
  const selectedWorker = document.getElementById('worker-select').value;
  const selectedActivity = document.getElementById('activity-select').value;

  if (selectedWorker && selectedActivity) {
    const timerId = `${selectedWorker}-${selectedActivity}`;
    if (timers[timerId]) {
      clearInterval(timerIntervals[timerId]);
      delete timers[timerId];
      delete timerIntervals[timerId];
    }
  } else {
    alert('Seleccione un trabajador y una actividad');
  }
}

function updateTimer(timerId) {
  const timerElement = document.getElementById('timer');
  const startTime = timers[timerId].startTime;
  const elapsedTime = Math.round((new Date() - startTime) / 1000);
  const minutes = Math.floor(elapsedTime / 60);
  const seconds = elapsedTime % 60;
  timerElement.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function updateReportsTable() {
  const reportsTableBody = document.getElementById('reports-table-body');
  reportsTableBody.innerHTML = '';

  reports.forEach(report => {
    const row = document.createElement('tr');
    const totalTime = workers.flatMap(worker => worker.activities).reduce((acc, activity) => acc + (activity.durationInSeconds || 0), 0);
    const activity = activities.find(activity => activity.name === report.activity);
    const ratePerMinute = (activity.perHour / 60) + parseFloat(activity.perMinute);
    const percentage = ((report.durationMinutes * 60 + report.durationSeconds) / totalTime) * 100;

    row.innerHTML = `
      <td>${report.worker}</td>
      <td>${report.activity}</td>
      <td>${report.startTime}</td>
      <td>${report.durationMinutes}</td>
      <td>${report.durationSeconds}</td>
      <td>${percentage.toFixed(2)}%</td>
    `;
    reportsTableBody.appendChild(row);
  });
}
